for i in range (1,9):
    input (i*4)

for y in range (-30,1):
    input (y-1)

for x in range (1,12):
    print (x+1) 
    input  ('AM') 

for c in range (12,24):
    print (c+1) 
    input ('PM')

evengetallen = 22, 24, 26, 28, 30, 32, 34, 34, 36, 38, 40, 42, 44, 46, 48, 50
print (evengetallen)