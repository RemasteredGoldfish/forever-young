week = ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo']
i = 0
while i < len(week): #len() = length of the list
    print(week[i])
    i = i + 1
