Getal = 20
while Getal <= 50:
    print(Getal)
    Getal = Getal + 2