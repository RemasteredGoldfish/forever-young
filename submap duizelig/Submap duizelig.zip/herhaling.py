while True:
    answer = input('Schrijf hier quit ')
    if answer == 'quit':
        quit()
    else:
        continue 