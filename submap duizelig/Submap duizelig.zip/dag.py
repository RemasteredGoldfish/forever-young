ochtend = 1
while ochtend <= 12:
    print (ochtend, 'AM')
    ochtend = ochtend + 1

midag = 1
while midag <= 12:
    print(midag, 'PM')
    midag = midag + 1