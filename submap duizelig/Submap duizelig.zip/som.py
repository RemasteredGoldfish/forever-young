teller = 1000
while teller:
    print(teller)
    teller -= 50
