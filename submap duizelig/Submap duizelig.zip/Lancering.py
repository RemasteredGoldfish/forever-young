teller = 30
while teller:
    print(teller)
    teller -= 1
print('Lancering! ')